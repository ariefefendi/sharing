CREATE TABLE student (
    id int NOT NULL AUTO_INCREMENT,
    name VARCHAR (255),
    PRIMARY KEY (ID)
);

INSERT INTO student(id, name) VALUES
(1, 'A'),
(2, 'B'),
(3, 'C');