    @include('template.head')
    <!-- navbar -->
    @include('template.navbar-side')

    <main class="main-content">
      <div class="position-relative iq-banner">
        
      @include('template.navbar-top')
      @include('template.header')

          @yield('content')
      
      <!-- footer -->
      @include('template.footer')