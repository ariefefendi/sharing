<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Administrator\Dashboard;
use App\Http\Controllers\Administrator\master\ControllerBarang;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Dashboard
Route::controller(Dashboard::class)->group(function () {
    Route::get('/dashboard', 'index');
});

// Barang
Route::controller(ControllerBarang::class)->group(function () {
    Route::get('/data-barang', 'index');
    Route::post('/product/getDataAll', 'getDataAll');
    Route::get('/product/getDataSelect', 'getDataSelect');
    Route::post('/product/insert', 'Insert');
    Route::put('/product/update', 'Update');
    Route::delete('/product/destroy', 'Destroy');
});
