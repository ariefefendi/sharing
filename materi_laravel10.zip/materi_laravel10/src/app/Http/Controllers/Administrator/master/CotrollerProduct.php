<?php

namespace App\Http\Controllers\Administrator\master;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Throwable;

class CotrollerProduct extends Controller
{

	public function index()
	{
		return view('master.product');
	}

	public function getDataAll(Request $request)
	{
		$filtervalue = $request->input('filtervalue');
		$filtertext = $request->input('filtertext');
		$start = $request->input('start');
		$length = $request->input('length');
		$sql = DB::table('products')
			->select(DB::raw('id, name, price'))
			->where($filtervalue, 'like', '%' . $filtertext . '%')
			->limit($length, $start);

		$queryall = $sql->get();
		$data = $queryall;
		$total = $sql->count();
		$dataRecord = array(
			"RecordsTotal" => $total,
			"RecordsFiltered" => $total,
			"Data" => $data,
		);
		return json_encode($dataRecord);
	}

	// done
	public function GetDataSelect(Request $request)
	{
		$id = $request->id;
		// main Query.
		$sql = DB::table('products')
			->select(DB::raw('products.*'))
			->where('products.id', '=', $id);
		$res = $sql->get();
		return json_decode($res);
	}

	// done
	public function Insert(Request $request)
	{
		$current_time = Carbon::now();
		// main data insert.
		$Data = [
			'name' => $request->input('name'),
			'price' => $request->input('price'),
		];

		try {
			// going to insert if unerror.
			DB::table("products")->insert($Data);
			$status = "successfully inserted";
		} catch (Throwable $e) {
			report($e);
		}
		return json_encode(array("result" => $status));
	}

	public function Update(Request $request)
	{
		$d = $request->input('id');
		// main data insert.
		$Data = [
			'name' => $request->input('name'),
			'price' => $request->input('price'),
		];
		$tes = DB::table('products')->where('id', $d)->update($Data);
		$status = "Updated";
		return json_encode(array("result" => $status));
	}
	// done
	public function destroy(Request $request)
	{
		$id = $request->input('id');
		DB::table('products')->where('id', '=', $id)->delete();
		return json_encode(array("result" => "OK"));
	}
}
