<!doctype html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
      <title>Hope UI | Responsive Bootstrap 5 Admin Dashboard Template</title>
      
      <!-- Favicon -->
      <link rel="shortcut icon" href="<?php echo e(url('/')); ?>/assets/images/favicon.ico">
      
      <!-- Library / Plugin Css Build -->
      <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/core/libs.min.css">
      
      <!-- Aos Animation Css -->
      <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/vendor/aos/dist/aos.css">
      
      <!-- Hope Ui Design System Css -->
      <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/hope-ui.min.css?v=4.0.0">
      
      <!-- Custom Css -->
      <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/custom.min.css?v=4.0.0">
      
      <!-- Dark Css -->
      <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/dark.min.css">
      
      <!-- Customizer Css -->
      <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/customizer.min.css">
      
      <!-- RTL Css -->
      <link rel="stylesheet" href="<?php echo e(url('/')); ?>/assets/css/rtl.min.css">
      

    <!-- install knockout js -->
    <script src="<?php echo e(url('/')); ?>/mvvm_assets/js/jquery.min.js"></script>
    
    <!-- knockout js -->
    <script src="<?php echo e(url('/')); ?>/mvvm_assets/knockout/knockout_3.4.2.js"></script>
    <script src="<?php echo e(url('/')); ?>/mvvm_assets/knockout/knockout.mapping-latest.js"></script>
    <script src="<?php echo e(url('/')); ?>/mvvm_assets/knockout/knockout-file-bindings.js"></script>
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/mvvm_assets/knockout/knockout-file-bindings.css">
    
    <!-- data tables -->
    
    <!-- alert / sweetalert -->
    <script src="<?php echo e(url('/')); ?>/mvvm_assets/alert/sweetalert.min.js"></script>
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/mvvm_assets/alert/sweetalert.css">

    <!-- <script src="https://ajax.aspnetcdn.com/ajax/knockout/knockout-3.5.0.js"></script> -->
      <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
      <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
      


      <script>
        var model = {
            Processing : ko.observable(),
            ProcessingContent : ko.observable(false),
            CheckId : ko.observable(false),
        }
      </script>
      
  </head>
  <body class="  ">
    <!-- loader Start -->
    <div id="loading">
      <div class="loader simple-loader" data-bind="visible: model.Processing() == true">
          <div class="loader-body">
          </div>
      </div>    </div>
    <!-- loader END --><?php /**PATH D:\serv8.1\xampp\htdocs\testLaravel10\resources\views/template/head.blade.php ENDPATH**/ ?>