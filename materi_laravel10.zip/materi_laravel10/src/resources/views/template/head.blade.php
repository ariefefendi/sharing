<!doctype html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Belajar Laravel 10</title>

    <!-- Favicon -->

    <!-- Library / Plugin Css Build -->
    <link rel="stylesheet" href="{{ url('/') }}/assets/css/core/libs.min.css" />

    <!-- Aos Animation Css -->
    <link rel="stylesheet" href="{{ url('/') }}/assets/vendor/aos/dist/aos.css" />

    <!-- Hope Ui Design System Css -->
    <link rel="stylesheet" href="{{ url('/') }}/assets/css/hope-ui.min.css?v=2.0.0" />

    <!-- Custom Css -->
    <link rel="stylesheet" href="{{ url('/') }}/assets/css/custom.css?v=1.0.0" />
    <link rel="stylesheet" href="{{ url('/') }}/assets/css/custom.min.css?v=2.0.0" />

    <!-- Dark Css -->
    <link rel="stylesheet" href="{{ url('/') }}/assets/css/dark.min.css" />

    <!-- Customizer Css -->
    <link rel="stylesheet" href="{{ url('/') }}/assets/css/customizer.min.css" />

    <!-- RTL Css -->
    <link rel="stylesheet" href="{{ url('/') }}/assets/css/rtl.min.css" />

    <!-- underscrore -->
    <script type="text/javascript" src="{{ url('/') }}/assetsadmin/js/underscore.js"></script>
    <!-- jquery -->
    <script src="{{ url('/') }}/assetsadmin/js/jquery.min.js"></script>
    <!--<script src="{{ url('/') }}/assetsadmin/js/jquery_v3.6.0.min.js"></script>-->
    <!-- <script src="https://code.jquery.com/jquery-2.2.4.min.js"></script> -->
    <script src="{{ url('/') }}/assets/js/core/libs.min.js"></script>
    <script src="{{ url('/') }}/assetsadmin/js/jquery.serializejson.js"></script>

    <!-- knockout -->
    <!-- https://cdnjs.cloudflare.com/ajax/libs/knockout/3.5.0/knockout-min.js -->
    <!-- <script src="{{ url('/') }}/assetsadmin/knockout/knockout_3.4.2.js"></script> -->
    <script src="https://ajax.aspnetcdn.com/ajax/knockout/knockout-3.5.0.js"></script>
    <script src="{{ url('/') }}/assetsadmin/knockout/knockout.mapping-latest.js"></script>
    <script src="{{ url('/') }}/assetsadmin/knockout/knockout-file-bindings.js"></script>
    <link href="{{ url('/') }}/assetsadmin/knockout/knockout-file-bindings.css">

    <!-- token input -->
    <link href="{{ url('/') }}/assetsadmin/token_input/token-input.css" rel="stylesheet">
    <link href="{{ url('/') }}/assetsadmin/token_input/token-input-facebook.css" rel="stylesheet">
    <script src="{{ url('/') }}/assetsadmin/token_input/jquery.tokeninput.js"></script>

    <!-- alert -->
    <link href="{{ url('/') }}/assetsadmin/alert/sweetalert.css" rel="stylesheet" type="text/css">
    <script src="{{ url('/') }}/assetsadmin/alert/sweetalert.min.js"></script>

    <script src="{{ url('/') }}/assets_beranda/js/generatepass.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

    <script>
        var model = {
            Processing: ko.observable(true),
            ProcessingContent: ko.observable(false),
            checkPass: ko.observable(false),
            CheckId: ko.observable(false),
            changeRupiah: ko.observable(''),
            URI_PAGE: 4, // setup uri access on pages.
            CheckValue: ko.observable(false),
            errorMessage: ko.observable('This field is required!'),
            notAllowedMessage: ko.observable('Email Not Allowed!'),
            acceptMessage: ko.observable('Email is allowed.'),
            giftWrap: ko.observable(true),
        }

        model.changeRupiah = function(value) {
            var number_string = value.toString(),
                sisa = number_string.length % 3,
                rupiah = number_string.substr(0, sisa),
                ribuan = number_string.substr(sisa).match(/\d{3}/g);
            if (ribuan) {
                separator = sisa ? '.' : '';
                rupiah += separator + ribuan.join('.');
                rupiah = 'Rp ' + rupiah;
            }
            return rupiah;
            // Cetak hasil
            // document.write(rupiah); // Hasil: r23.456.789
        }
    </script>


</head>

<body class="light theme-default theme-with-animation card-default theme-color-default">
    <!-- loader Start -->
    <div class="ProcessingContent h-100" data-bind="visible: model.Processing() == true">
        <div class="overlay">
            <div class="overlayDoor"></div>
            <div class="overlayContent">
                <div class="loading">
                    <div class="inner"></div>
                </div>
            </div>
        </div>
    </div>

    <script>
        model.Resource = {
            logout: 'url-logout',
            /* isikan value dari rootingnya  (url dengan uri = 1)*/
            notif: 'Anda yakin? Anda Akan ',
        }
    </script>

    <style>
        .ProcessingContent {
            height: 100%;
            position: fixed;
            z-index: 999999;
            left: 0;
            top: 0;
            width: 100%;
            background: black;
            opacity: 40%;
        }

        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 100000000;

            .overlayContent {
                position: relative;
                width: 100%;
                height: 100%;
                display: flex;
                justify-content: center;
                align-items: center;
                flex-direction: column;
            }
        }

        .loading {
            width: 128px;
            height: 128px;
            border: 3px solid #fff;
            border-bottom: 3px solid transparent;
            border-radius: 50%;
            position: relative;
            animation: spin 1s linear infinite;
            display: flex;
            justify-content: center;
            align-items: center;

            .inner {
                width: 64px;
                height: 64px;
                border: 3px solid transparent;
                border-top: 3px solid #fff;
                border-radius: 50%;
                animation: spinInner 1s linear infinite;
            }
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }

        @keyframes spinInner {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(-720deg);
            }
        }
    </style>
