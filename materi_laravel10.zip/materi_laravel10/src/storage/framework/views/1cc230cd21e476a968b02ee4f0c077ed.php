<!--  fungsi logout ada di file :  -->
<script>
    var material = {
        Recordmaterial: ko.mapping.fromJS(model.masterModel),
        Listmaterial: ko.observableArray([]),
        Mode: ko.observable(''),
    }

    // PARENT NAVBAR MENU 0 = MENU UTAMA
    model.selectsParentsMenu = function() {
        url = "/Controll_navbar/getDataMenu",
            ajaxPost(url, material.Recordmaterial, function(res) {
                $.each(res, function(i, item) { // looping data semua data
                    var r = res[i];
                    // console.log(r);

                    if (res[i].menuparentid == 0) { // tangkap data parent menu (0)
                        var r = res[i];
                        console.log(r.menuname);

                        $.each(res, function(i,
                            item) { // looping data berdasarkan menuparentid selain 0
                            if (res[i].menuparentid == 2) {
                                console.log(res[i].menuname); // print menuname
                            }
                        });

                    }

                    // material.Recordmaterial.selectJenisPakets(selectJenisPakets);
                });
            });
    }
</script>

<aside class="sidebar sidebar-default sidebar-white sidebar-base navs-rounded-all ">
    <div class="sidebar-header d-flex align-items-center justify-content-start">
        <a href="#" class="navbar-brand">
            <h4 class="logo-title">Admin</h4>
        </a>
        <div class="sidebar-toggle" data-toggle="sidebar" data-active="true">
            <!--<i class='bx bx-home-alt'></i>-->
            <i class="icon">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
                    xmlns="http://www.w3.org/2000/svg">
                    <path d="M4.25 12.2744L19.25 12.2744" stroke="currentColor" stroke-width="1.5"
                        stroke-linecap="round" stroke-linejoin="round"></path>
                    <path d="M10.2998 18.2988L4.2498 12.2748L10.2998 6.24976" stroke="currentColor" stroke-width="1.5"
                        stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
            </i>
        </div>
    </div>
    <div class="sidebar-body pt-0 data-scrollbar">
        <div class="sidebar-list">
            <!-- Sidebar Menu Start -->
            <ul class="navbar-nav iq-main-menu" id="sidebar-menu">
                <li class="nav-item static-item">
                    <a class="nav-link static-item disabled" href="#" tabindex="-1">
                        <span class="default-icon">Home</span>
                        <span class="mini-icon">-</span>
                    </a>
                </li>
            </ul>
            <!-- Sidebar Menu End -->
        </div>
    </div>
    <div class="sidebar-footer"></div>
</aside>
<main class="main-content">
<?php /**PATH /var/www/html/resources/views/template/navbar-side.blade.php ENDPATH**/ ?>