    <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- navbar -->
    <?php echo $__env->make('template.navbar-side', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="main-content">
      <div class="position-relative iq-banner">
        
      <?php echo $__env->make('template.navbar-top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <?php echo $__env->yieldContent('content'); ?>
      
      <!-- footer -->
      <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\serv8.1\xampp\htdocs\testLaravel10\resources\views/admin_template.blade.php ENDPATH**/ ?>