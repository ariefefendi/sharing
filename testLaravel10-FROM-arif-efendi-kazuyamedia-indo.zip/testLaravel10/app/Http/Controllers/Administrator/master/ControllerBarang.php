<?php
namespace App\Http\Controllers\Administrator\master;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Carbon\Carbon;
use Throwable;



class ControllerBarang extends Controller
{

    public function index()
    {
        return view('master.Barang');
    }

    public function getDataAll(Request $request)
    {   // for get post filter.
        $filtervalue = $request->input('filtervalue');
        $filtertext = $request->input('filtertext');
        // filter for limit data.
        $start = $request->input('start');
        $length = $request->input('length');
        // query
        $sql = DB::table('products')
            ->select(DB::raw('id, name, price, created_at, updated_at'))
            ->where($filtervalue, 'like', '%' . $filtertext . '%')
            ->limit($length, $start);

        // execute
        $queryall = $sql->get();
        $data = $queryall;
        $total = $sql->count();
        $dataRecord = array(
            "RecordsTotal" => $total,
            "RecordsFiltered" => $total,
            "Data" => $data,
        );
        return $dataRecord;
    }

    public function getDataSelect(Request $request)
    {
        $id = $request->id;
        // query
        $sql = DB::table('products')
            ->select(DB::raw("products.*"))
            ->where("products.id", "=", $id);
        $res = $sql->get();
        return $res;
    }

    // insert data
    public function Update(Request $request)
    {
        $current_time = Carbon::now()->setTimezone("Asia/Jakarta");
        $id = $request->input('id');
        $data = array(
            "name" => $request->input('name'),
            "price" => $request->input('price'),
            "updated_at" => $current_time,
        );
        DB::table("products")->where("id", $id)->update($data);
        $status = "Successfully updated!";
        return $res = array(
            "result" => $status
        );
    }

    // update data
    public function Insert(Request $request)
    {
        $current_time = Carbon::now()->setTimezone("Asia/Jakarta");
        $data = array(
            "name" => $request->input('name'),
            "price" => $request->input('price'),
            "created_at" => $current_time,
        );
        DB::table("products")->insert($data);
        $status = "Successfully inserted!";
        return $res = array(
            "result" => $status
        );
    }

    // remove data
    public function Destroy(Request $request)
    {
        $id = $request->input('id');
        DB::table('products')->where('id',$id)->delete();
        $status = "Successfully deleted!";
        return $res = array(
            "result" => $status
        );
    }


}