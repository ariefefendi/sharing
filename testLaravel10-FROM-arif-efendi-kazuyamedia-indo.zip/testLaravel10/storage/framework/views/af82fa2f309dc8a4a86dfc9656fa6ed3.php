 <?php $__env->startSection('content'); ?>
    <script>
        model.masterModel = {
            id: "",
            name: "",
            price: "",
        };
        var material = {
            Recordmaterial: ko.mapping.fromJS(model.masterModel),
            Listmaterial: ko.observableArray([]),
            Mode: ko.observable(""),
            FilterText: ko.observable(""),
            FilterValue: ko.observable("name"),
        };

        material.back = function(tab) {
            material.Mode("");
            material.grid.ajax.reload(null, true);
            ko.mapping.fromJS(model.masterModel, material.Recordmaterial);
            model.activetab(tab);
        };
        material.selectdata = function(id) {
           console.log(id);
           material.back(0);
           material.Mode('Update');
            
           var url = "/product/getDataSelect";
            $.ajax({
                url: url,
                type: "GET",
                data: { id: id },
                success: function(res) {
                    // console.log(res);
                    ko.mapping.fromJS(res[0], material.Recordmaterial);
                }
            });

        };

        material.save = function() {
            var val = material.Recordmaterial;
            var mode = material.Mode();
            var url = "product/insert";
            var method = "POST";

            // console.log(mode);
            if(mode == 'Update') {
                var url = "product/update";
                var method = "PUT";
            }

            $.ajax({
                url: url,
                method: method,
                data: val,
                success: function(res){
                    var res = res;
                    console.log(res);
                    material.back(1);
                },
            });

        };

        material.remove = function(id) {
            $.ajax({
                url: "/product/destroy",
                method: "DELETE",
                data: {id : id},
                success: function(res){
                    var res = res;
                    console.log(res);
                    material.back(1);
                },
            });
        };


    </script>

    <div class="conatiner-fluid content-inner mt-n5 py-0">
        <div class="row">
            <div class="col-lg-12">
                <div class="card rounded">
                    <div class="card-body" data-bind="with:material">
                        <ul class="nav nav-tabs customtab" id="tabnavform" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="form-tab" data-bs-toggle="tab"
                                    data-bs-target="#tabform" type="button" role="tab" aria-controls="home"
                                    aria-selected="true">
                                    Form
                                </button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="listdata-tab" data-bs-toggle="tab" data-bs-target="#tablist"
                                    type="button" role="tab" aria-controls="profile" aria-selected="false">
                                    List
                                </button>
                            </li>
                        </ul>
                        <div class="tab-content" id="tabnavform-content">
                            <div class="tab-pane fade show active" id="tabform" role="tabpanel"
                                aria-labelledby="home-tab">
                                <div class="row p-t-23 margMin">
                                    <div class="col-md-12 margMin">
                                        <div class="form-group">
                                            <button
                                                data-bind="click:function(){back(1);}, visible: material.Mode() == 'Update'"
                                                data-toggle="tooltip" data-placement="top" data-original-title="Kembali"
                                                class="btn btn-sm btn-outline-warning mr-1 mb-1">
                                                Back
                                            </button>

                                            <button data-bind="click:save, data-original-title:Mode" type="submit"
                                                data-toggle="tooltip" data-placement="top" data-original-title="simpan"
                                                class="btn btn-icon btn-outline-success mr-1 mb-1">
                                                Save
                                            </button>
                                            <button
                                                data-bind=" click:function(){remove(Recordmaterial.id());}, visible: material.Mode() == 'Update'"
                                                class="btn btn-icon btn-outline-danger mr-1 mb-1">
                                                Delete
                                            </button>
                                            <button data-bind=" visible: material.Mode() == 'Update'" type="button"
                                                class="btn btn-icon btn-light mr-1 mb-1">
                                                no :
                                                <i class="bx" data-bind=" text: Recordmaterial.id()"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>

                                <!-- loader Processing Content -->
                                

                                <!-- FORM -->
                                <div class="form form-vertical">
                                    <div class="form-body">
                                        <div class="row" data-bind="with: Recordmaterial">

                                        <div class="mb-3 form-floating">
                                            <input type="text" name="txtname" data-bind="value: name" class="form-control" id="floatingInput1" placeholder="name@example.com">
                                            <label for="floatingInput1">Product</label>
                                        </div>

                                        <div class="mb-3 form-floating">
                                            <input type="number" name="txtprice" data-bind="value: price" class="form-control" id="floatingInput1" placeholder="name@example.com">
                                            <label for="floatingInput1">Price</label>
                                        </div>

                                        </div>
                                    </div>
                                    <!-- ./ END FORM -->
                                </div>
                            </div>
                            <!-- data table -->
                            <div class="tab-pane fade" id="tablist" role="tabpanel" aria-labelledby="profile-tab">
                                <section id="basic-datatable">
                                    <div class="row" data-bind="with: material">
                                        <!-- filter -->
                                       
                                        <!-- ./filter -->
                                        <div class="col-12">
                                            <div class="table-responsive animated fadeIn">
                                                <table id="myTable" width="100%"
                                                    class="table table-striped dataTable">
                                                    <thead>
                                                        <tr>
                                                            <th>name</th>
                                                            <th>price</th>
                                                            <th>created_at</th>
                                                            <th>updated_at</th>
                                                            <th>ACTION</th>
                                                        </tr>
                                                    </thead>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </div>
                            <!-- end data table -->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
           
            $(document).ready(function() {
                material.grid = $("#myTable").DataTable({
                    paging: false,
                    retrieve: true,
                    processing: true,
                    serverSide: true,
                    ordering: false,
                    bLengthChange: false,
                    bInfo: true,
                    ajax: {
                        url: "/product/getDataAll",
                        type: "POST",
                        data: function(d) {
                            d["filtervalue"] = material.FilterValue();
                            d["filtertext"] = material.FilterText();
                            return d;
                        },
                        dataSrc: function(json) {
                            // json.draw = 1;
                            json.recordsTotal = json.RecordsTotal;
                            json.recordsFiltered = json.RecordsFiltered;

                            if (json.Data) return json.Data;
                            else return [];
                        },
                    },
                    searching: false,
                    columns: [
                        { data: "name" },
                        { data: "price" },
                        { data : "created_at" },
                        { data : "updated_at" },
                        {
                            data: "id",
                            render: function(data, type, full, meta) {
                                return (
                                    "<button class='btn btn-sm btn-info' onClick='material.selectdata(\"" + data + "\")'><svg class='icon-20' width='20' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'><path opacity='0.4' d='M19.9927 18.9534H14.2984C13.7429 18.9534 13.291 19.4124 13.291 19.9767C13.291 20.5422 13.7429 21.0001 14.2984 21.0001H19.9927C20.5483 21.0001 21.0001 20.5422 21.0001 19.9767C21.0001 19.4124 20.5483 18.9534 19.9927 18.9534Z' fill='currentColor'></path><path d='M10.309 6.90385L15.7049 11.2639C15.835 11.3682 15.8573 11.5596 15.7557 11.6929L9.35874 20.0282C8.95662 20.5431 8.36402 20.8344 7.72908 20.8452L4.23696 20.8882C4.05071 20.8903 3.88775 20.7613 3.84542 20.5764L3.05175 17.1258C2.91419 16.4915 3.05175 15.8358 3.45388 15.3306L9.88256 6.95545C9.98627 6.82108 10.1778 6.79743 10.309 6.90385Z' fill='currentColor'></path><path opacity='0.4' d='M18.1208 8.66544L17.0806 9.96401C16.9758 10.0962 16.7874 10.1177 16.6573 10.0124C15.3927 8.98901 12.1545 6.36285 11.2561 5.63509C11.1249 5.52759 11.1069 5.33625 11.2127 5.20295L12.2159 3.95706C13.126 2.78534 14.7133 2.67784 15.9938 3.69906L17.4647 4.87078C18.0679 5.34377 18.47 5.96726 18.6076 6.62299C18.7663 7.3443 18.597 8.0527 18.1208 8.66544Z' fill='currentColor'></path></svg></button> &nbsp; <button  id='sa-warning' class='btn btn-icon btn-danger' onClick='material.remove(\"" + data + "\")' id='sa-warning'> <span class='icon'><svg class='icon-20' width='20' viewBox='0 0 24 24' fill='none' xmlns='http://www.w3.org/2000/svg'><path d='M19.3248 9.46826C19.3248 9.46826 18.7818 16.2033 18.4668 19.0403C18.3168 20.3953 17.4798 21.1893 16.1088 21.2143C13.4998 21.2613 10.8878 21.2643 8.27979 21.2093C6.96079 21.1823 6.13779 20.3783 5.99079 19.0473C5.67379 16.1853 5.13379 9.46826 5.13379 9.46826' stroke='currentColor' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'></path><path d='M20.708 6.23975H3.75' stroke='currentColor' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'></path><path d='M17.4406 6.23973C16.6556 6.23973 15.9796 5.68473 15.8256 4.91573L15.5826 3.69973C15.4326 3.13873 14.9246 2.75073 14.3456 2.75073H10.1126C9.53358 2.75073 9.02558 3.13873 8.87558 3.69973L8.63258 4.91573C8.47858 5.68473 7.80258 6.23973 7.01758 6.23973' stroke='currentColor' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'></path></svg></span></button>"
                                );
                            },
                        },
                    ],
                });
            });
        </script>
    <?php $__env->stopSection(); ?>
</div>

<?php echo $__env->make('admin_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\serv8.1\xampp\htdocs\testLaravel10\resources\views/master/Barang.blade.php ENDPATH**/ ?>