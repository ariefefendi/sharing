<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Administrator\master\CotrollerProduct;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::controller(CotrollerProduct::class)->group(function () {
    Route::get('/', 'index');
    Route::post('admin/product/getDataAll', 'getDataAll');
    Route::get('admin/product/GetDataSelect', 'GetDataSelect');
    Route::post('admin/product/Insert', 'Insert');
    Route::put('admin/product/Update', 'Update');
    Route::delete('admin/product/destroy', 'destroy');
});
