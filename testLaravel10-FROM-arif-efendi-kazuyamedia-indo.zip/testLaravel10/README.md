### Installation master-app-laravel

## Part 1 - Installation

    a. composer 2.2 or higher
    b. visula studio code or other text editor

1. composer create-project laravel/laravel:10.\* testLaravel10
2. to run your first project = you must into in main directory project and type :
   `php artisan serve`.

## Part 2 - integration Hope UI Interface & knockout js for mvvm pettern.

1. download resource : https://drive.google.com/drive/folders/1DwVBGx5qlqJZNN7zigWeij2TboUTIcgv?usp=sharing
2. extract to public folder in your project
3. create file `admin_template.blade.php` in resources/views
4. create folder template in resources/views
5. create file `head.blade.php`, `footer.blade.php`, `navbar-side.blade.php`, `navbar-top.blade.php` in resources/views/template

6. adding to head file :
   `<script src="https://ajax.aspnetcdn.com/ajax/knockout/knockout-3.5.0.js"></script>
     <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
     <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>`

<!-- Run Postgree Sql
if
Postgree 10 : pg_ctl.exe restart -D "C:\Program Files\PostgreSQL\10\data" ;
Postgree 15 : pg_ctl -D "C:\Program Files\PostgreSQL\15\data" start ; -->

# Add / install Package

<!-- -   Extension For DateTime :
    `composer require nesbot/carbon`
    how to use : https://carbon.nesbot.com/docs/#api-introduction -->

-   here text
    `code`
    how to use :

-   Migration -
    create file : php artisan make:migration your_file_migrate
    running migrate : php artisan migrate
    status migrate : php artisan migrate:status

-   Routes -
    list routes : php artisan route:list
    cache clear : php artisan route:cache

<!-- -   Seeder -
    Create Seeder : php artisan make:seeder hobiesSeeder
    run : php artisan db:seed -->

<!-- FOR LOOPING IN SQL -->
<!-- do $$
begin
  for counter in 1..6 by 2 loop
    raise notice 'counter: %', counter;
  end loop;
end; $$ -->

<!-- material grid data table -->

material.grid = $("#myTable").DataTable({
"processing": true,
"serverSide": true,
"ordering": false,
"bLengthChange": false,
"responsive": true,
"ajax": {
"url": "",
"type": "POST",
"data": function (d) {
d['filtervalue'] = material.FilterValue();
d['filtertext'] = material.FilterText();
return d;
},
"dataSrc": function (json) {
// json.draw = 1;
json.recordsTotal = json.RecordsTotal;
json.recordsFiltered = json.RecordsFiltered;

    				if (json.Data)
    					return json.Data;
    				else
    					return [];
    			},
    		},
    		"searching": false,
    		"columns": [
    			{ "data": "" },
    			{
    				"data": "",
    				"render": function (data, type, full, meta) {
    					return "<button class='btn btn-icon btn-info' onClick='material.selectdata(\"" + data + "\")'><i class='bx bx-pencil'></i></button> &nbsp; <button  id='sa-warning' class='btn btn-icon btn-danger' onClick='material.remove(\"" + data + "\")' id='sa-warning' ><i class='bx bx-trash'></i></button>";
    				}
    			}
    		],
    	});

-   tambahkan csrf token pada head.
<meta name="csrf-token" content="{{ csrf_token() }}">

-   perubahan pada controller
-   serta beberapa perubahan bagian frontend. ( pada sesi ini silahkan di replace saja dari file yang telah saya lakukan perubahan )
